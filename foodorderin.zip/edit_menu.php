<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session
session_start();

// Cek apakah user sudah login, jika tidak redirect ke login page
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Mengambil ID menu dari parameter URL
$id = $_GET['id'];

// Mengambil data menu berdasarkan ID untuk ditampilkan di form
$menu = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM menu WHERE id=$id"));

// Mengecek apakah form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    // Update data menu di database
    $sql = "UPDATE menu SET nama_makanan='$nama', harga='$harga', deskripsi='$deskripsi' WHERE id=$id";
    mysqli_query($koneksi, $sql);

    // Setelah berhasil update, kembali ke halaman menu
    header("Location: menu.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Menu - FoodOrderin</title>
    <!-- CDN Bootstrap untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e0f2fe, #dbeafe);
            font-family: 'Segoe UI', sans-serif;
        }
        .edit-card {
            background-color: #ffffff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            padding: 40px;
            width: 100%;
            max-width: 600px;
        }
        .form-title {
            font-weight: bold;
            color: #1e3a8a;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .btn-blue {
            background-color: #2563eb;
            color: white;
            border: none;
        }
        .btn-blue:hover {
            background-color: #1e40af;
        }
    </style>
</head>
<body>
    <!-- Container form edit menu -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="edit-card">
            <h3 class="text-center mb-4 form-title">Edit Menu Makanan 🍽️</h3>
            
            <!-- Form Edit Menu -->
            <form method="POST">
                <!-- Input Nama Makanan -->
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Makanan</label>
                    <input name="nama" id="nama" class="form-control" value="<?= $menu['nama_makanan'] ?>" required>
                </div>

                <!-- Input Harga -->
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga (Rp)</label>
                    <input name="harga" id="harga" type="number" class="form-control" value="<?= $menu['harga'] ?>" required>
                </div>

                <!-- Input Deskripsi -->
                <div class="mb-4">
                    <label for="deskripsi" class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" required><?= $menu['deskripsi'] ?></textarea>
                </div>

                <!-- Tombol Submit dan Batal -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-blue">Update Menu</button>
                    <a href="menu.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Menyisipkan footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
