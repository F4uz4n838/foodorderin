<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session (jika perlu akses data login)
session_start();

// Mengecek apakah ada input pencarian dari URL
$search = isset($_GET['cari']) ? $_GET['cari'] : '';

// Query untuk mengambil data menu dari database berdasarkan keyword pencarian
$query = "SELECT * FROM menu WHERE nama_makanan LIKE '%$search%'";

// Menjalankan query ke database
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Menu - FoodOrderin</title>
    <!-- Link Bootstrap untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <!-- Judul halaman -->
        <h3>Daftar Menu</h3>

        <!-- Form pencarian menu berdasarkan nama makanan -->
        <form method="get" class="mb-3">
            <input type="text" name="cari" placeholder="Cari makanan..." class="form-control" value="<?= $search ?>">
        </form>

        <!-- Tombol untuk menambah menu baru -->
        <a href="tambah_menu.php" class="btn btn-success mb-3">+ Tambah Menu</a>

        <!-- Tabel untuk menampilkan data menu -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Deskripsi</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan data menu satu per satu dalam tabel -->
                <?php while($menu = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $menu['nama_makanan'] ?></td>
                    <td><?= $menu['harga'] ?></td>
                    <td><?= $menu['deskripsi'] ?></td>
                    <td><img src="assets/img/<?= $menu['gambar'] ?>" width="100"></td>
                    <td>
                        <!-- Tombol Edit menu -->
                        <a href="edit_menu.php?id=<?= $menu['id'] ?>" class="btn btn-warning btn-sm">Edit</a>

                        <!-- Tombol Hapus menu dengan konfirmasi -->
                        <a href="hapus_menu.php?id=<?= $menu['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Tombol kembali ke dashboard -->
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>

    <!-- Menyisipkan footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
