<?php
// Memulai session untuk menyimpan data login admin
session_start();

// Menyambungkan ke database
include 'config/koneksi.php';

// Mengecek apakah form dikirim melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil input username dan password dari form
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Mengecek apakah username ada di database
    $query = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$user'");
    $data = mysqli_fetch_assoc($query); // Mengambil data user dalam bentuk array asosiatif

    // Validasi: user ditemukan, password cocok, dan role-nya adalah admin
    if ($data && password_verify($pass, $data['password']) && $data['role'] === 'admin') {
        // Jika berhasil login, simpan data ke session
        $_SESSION['login'] = true;
        $_SESSION['id'] = $data['id'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['role'] = $data['role'];

        // Redirect ke halaman dashboard admin
        header("Location: dashboard.php");
        exit;
    } else {
        // Jika gagal login, simpan pesan error
        $error = "Login gagal. Akun tidak ditemukan atau bukan admin.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login - FoodOrderin</title>
    <!-- Bootstrap CDN untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Container untuk memusatkan form login admin di tengah halaman -->
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <form method="POST" class="bg-white p-4 shadow rounded" style="min-width: 320px; max-width: 400px; width: 100%;">
            <h4 class="mb-3 text-center text-primary">Login Admin FoodOrderin</h4>

            <!-- Menampilkan pesan error jika login gagal -->
            <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <!-- Input username admin -->
            <input name="username" class="form-control mb-2" placeholder="Username Admin" required>

            <!-- Input password admin -->
            <input name="password" type="password" class="form-control mb-3" placeholder="Password" required>

            <!-- Tombol submit login -->
            <button type="submit" class="btn btn-primary w-100">Login Admin</button>

            <!-- Link kembali ke halaman login user -->
            <a href="login.php" class="d-block text-center mt-2 text-decoration-none text-secondary">Kembali ke Login User</a>
        </form>
    </div>

    <!-- Menyisipkan footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
