<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session
session_start();

// Validasi akses: hanya admin yang boleh mengakses file ini
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    // Jika tidak login atau bukan admin, arahkan ke halaman login
    header("Location: login.php");
    exit;
}

// Ambil ID pesanan dari URL dan ubah ke integer agar lebih aman
$id = (int)$_GET['id'];

// Update status pesanan menjadi 'Diterima' berdasarkan ID
mysqli_query($koneksi, "UPDATE pesanan SET status='Diterima' WHERE id=$id");

// Kembali ke halaman data pesanan setelah proses update selesai
header("Location: data_pesanan.php");
exit;
?>
