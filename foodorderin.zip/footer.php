<!-- footer.php -->

<!-- Bagian footer yang akan ditampilkan di bagian bawah halaman -->
<div class="text-center mt-5 p-3 bg-light text-muted border-top">
    <!-- Tampilkan tahun saat ini secara otomatis dengan PHP -->
    <small>&copy; <?= date('Y') ?> FoodOrderin 🍽️ - All rights reserved.</small>
</div>
