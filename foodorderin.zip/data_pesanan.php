<?php
// Menghubungkan ke database
include 'config/koneksi.php';
// Memulai session
session_start();

// Mengecek apakah user sudah login, jika tidak arahkan ke login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Ambil data user saat ini
$user_id = $_SESSION['id'];
$is_admin = $_SESSION['role'] == 'admin'; // Cek apakah user adalah admin

// Query data pesanan, jika admin tampilkan semua, jika user tampilkan hanya miliknya
$sql = $is_admin 
    ? "SELECT p.*, m.nama_makanan, m.harga, u.username 
       FROM pesanan p 
       JOIN menu m ON p.menu_id = m.id 
       JOIN users u ON p.user_id = u.id 
       ORDER BY p.tanggal DESC"
    : "SELECT p.*, m.nama_makanan, m.harga 
       FROM pesanan p 
       JOIN menu m ON p.menu_id = m.id 
       WHERE p.user_id = '$user_id'
       ORDER BY p.tanggal DESC";

// Eksekusi query
$pesanan = mysqli_query($koneksi, $sql);

// Inisialisasi total harga semua pesanan
$total_semua = 0;
$rows = [];

// Loop data pesanan dan hitung total per item + akumulasi total keseluruhan
while ($row = mysqli_fetch_assoc($pesanan)) {
    $total_item = $row['harga'] * $row['jumlah']; // Total untuk satu pesanan
    $total_semua += $total_item; // Akumulasi total
    $rows[] = $row + ['total_item' => $total_item]; // Simpan data dengan total per item
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pesanan</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: #f0f4ff;">
<div class="container mt-5">
    <h3 class="mb-4 text-center text-primary">Data Pesanan</h3>

    <!-- Tabel Data Pesanan -->
    <table class="table table-bordered table-hover bg-white shadow-sm">
        <thead class="table-light">
            <tr>
                <?php if ($is_admin) echo "<th>User</th>"; ?>
                <th>Menu</th>
                <th>Jumlah</th>
                <th>Harga Satuan</th>
                <th>Total</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $p): ?>
                <?php
                    // Ambil status & tentukan badge Bootstrap
                    $status = $p['status'] ?? 'Pending';
                    $badge = match($status) {
                        'Diterima' => 'success',
                        'Pending' => 'warning',
                        default => 'secondary'
                    };
                ?>
                <tr>
                    <?php if ($is_admin) echo "<td>" . $p['username'] . "</td>"; ?>
                    <td><?= $p['nama_makanan'] ?></td>
                    <td><?= $p['jumlah'] ?></td>
                    <td>Rp <?= number_format($p['harga'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($p['total_item'], 0, ',', '.') ?></td>
                    <td><?= $p['tanggal'] ?></td>
                    <td>
                        <!-- Badge Status -->
                        <span class="badge bg-<?= $badge ?>"><?= $status ?></span><br>

                        <!-- Status pembayaran -->
                        <?php if ($p['sudah_bayar']): ?>
                            <small class="text-success">✅ Sudah Dibayar</small>
                        <?php else: ?>
                            <small class="text-danger">❌ Belum Dibayar</small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <!-- Tombol untuk admin menerima pesanan -->
                        <?php if ($is_admin && $status == 'Pending'): ?>
                            <a href="terima_pesanan.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-success mb-1">Terima</a><br>
                        <?php endif; ?>

                        <!-- Tombol untuk user membayar jika sudah diterima -->
                        <?php if (!$is_admin && $status === 'Diterima' && !$p['sudah_bayar']): ?>
                            <a href="bayar.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-warning mb-1">Bayar</a><br>
                        <?php endif; ?>

                        <!-- Tombol hapus pesanan -->
                        <a href="hapus_pesanan.php?id=<?= $p['id'] ?>" 
                           class="btn btn-sm btn-outline-danger" 
                           onclick="return confirm('Yakin mau hapus pesanan ini?')">
                           Hapus
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>

        <!-- Footer tabel: total keseluruhan -->
        <tfoot>
            <tr class="table-info fw-bold">
                <?php if ($is_admin) echo "<td colspan='4'>"; else echo "<td colspan='3'>"; ?>
                Total Seluruh Pesanan
                </td>
                <td colspan="1">Rp <?= number_format($total_semua, 0, ',', '.') ?></td>
                <td colspan="3"></td>
            </tr>
        </tfoot>
    </table>

    <!-- Tombol kembali ke dashboard -->
    <div class="text-center mt-4">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
</div>

<!-- Menyisipkan footer -->
<?php include 'footer.php'; ?>
</body>
</html>
