<?php
session_start();
include 'config/koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];
$user_id = $_SESSION['id'];

$cek = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id=$id AND user_id=$user_id AND status='Diterima' AND sudah_bayar=0");
if (mysqli_num_rows($cek) === 0) {
    echo "<script>alert('Tidak ada pesanan yang perlu dibayar.'); window.location='data_pesanan.php';</script>";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pin = $_POST['pin'];
    
    // Validasi hanya kalau PIN kosong
    if (!empty($pin)) {
        mysqli_query($koneksi, "UPDATE pesanan SET sudah_bayar=1 WHERE id=$id");
        echo "<script>alert('Pesanan sedang diproses!'); window.location='dashboard.php';</script>";
        exit;
    } else {
        $error = "PIN tidak boleh kosong.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bayar Sekarang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: #f0f4ff;">
<div class="container mt-5">
    <div class="card shadow-sm p-4 mx-auto" style="max-width: 400px;">
        <h4 class="text-center mb-3">Konfirmasi Pembayaran</h4>
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="pin" class="form-label">Masukkan PIN untuk konfirmasi</label>
                <input type="password" name="pin" class="form-control" id="pin" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Bayar</button>
        </form>
    </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>
