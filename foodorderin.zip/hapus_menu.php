<?php
// Menghubungkan ke file koneksi database
include 'config/koneksi.php';

// Ambil ID menu dari parameter URL
$id = $_GET['id'];

// Hapus data menu dari database berdasarkan ID
mysqli_query($koneksi, "DELETE FROM menu WHERE id=$id");

// Setelah berhasil dihapus, arahkan kembali ke halaman menu
header("Location: menu.php");
exit;
?>
