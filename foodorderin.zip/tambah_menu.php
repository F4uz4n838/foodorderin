<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session
session_start();

// Mengecek apakah user sudah login, jika belum arahkan ke login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Mengecek apakah form disubmit dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data dari input form
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    // Menangani file gambar yang diupload
    $gambar = $_FILES['gambar']['name']; // Nama file gambar
    $tmp = $_FILES['gambar']['tmp_name']; // Lokasi sementara file

    // Memindahkan file dari folder sementara ke folder tujuan
    move_uploaded_file($tmp, "assets/img/" . $gambar);

    // Menyimpan data ke dalam tabel menu
    $sql = "INSERT INTO menu (nama_makanan, harga, deskripsi, gambar) 
            VALUES ('$nama', '$harga', '$deskripsi', '$gambar')";
    
    // Eksekusi query insert
    mysqli_query($koneksi, $sql);

    // Redirect ke halaman menu setelah data berhasil disimpan
    header("Location: menu.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Menu - FoodOrderin</title>
    <!-- Bootstrap CDN untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Container form tambah menu, dipusatkan -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="bg-white p-5 shadow rounded" style="width: 100%; max-width: 600px;">
            <h3 class="mb-4 text-center">Tambah Menu Makanan 🍛</h3>

            <!-- Form untuk input data menu -->
            <form method="POST" enctype="multipart/form-data">
                <!-- Input nama makanan -->
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Makanan</label>
                    <input name="nama" id="nama" class="form-control" placeholder="Contoh: Nasi Goreng" required>
                </div>

                <!-- Input harga -->
                <div class="mb-3">
                    <label for="harga" class="form-label">Harga (Rp)</label>
                    <input name="harga" id="harga" type="number" class="form-control" placeholder="Contoh: 15000" required>
                </div>

                <!-- Input deskripsi -->
                <div class="mb-3">
                    <label for="deskripsi" class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" placeholder="Contoh: Nasi goreng spesial dengan telur dan ayam" required></textarea>
                </div>

                <!-- Upload gambar -->
                <div class="mb-4">
                    <label for="gambar" class="form-label">Upload Gambar</label>
                    <input type="file" name="gambar" id="gambar" class="form-control" required>
                </div>

                <!-- Tombol simpan dan batal -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success">Simpan Menu</button>
                    <a href="menu.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Menyisipkan footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
