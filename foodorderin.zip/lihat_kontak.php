<?php
// Mulai session dan cek apakah admin sudah login
session_start();
include 'config/koneksi.php';

// Cek apakah user login dan rolenya admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil semua data dari tabel 'kontak'
$kontak = mysqli_query($koneksi, "SELECT * FROM kontak ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Kontak</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: #f0f4ff;">
<div class="container mt-5">
    <h3 class="mb-4 text-center text-primary">Pesan Masuk</h3>

    <!-- Tabel menampilkan daftar pesan kontak -->
    <table class="table table-bordered table-hover bg-white shadow-sm">
        <thead class="table-light">
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Pesan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($k = mysqli_fetch_assoc($kontak)): ?>
            <tr>
                <td><?= $k['nama'] ?></td>
                <td><?= $k['email'] ?></td>
                <td><?= $k['pesan'] ?></td>
                <td>
                    <!-- Tombol hapus data kontak -->
                    <a href="hapus_kontak.php?id=<?= $k['id'] ?>" 
                       class="btn btn-sm btn-danger" 
                       onclick="return confirm('Yakin ingin menghapus pesan ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Tombol kembali ke dashboard -->
    <div class="text-center mt-4">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
</div>

<!-- Footer -->
<?php include 'footer.php'; ?>
</body>
</html>
