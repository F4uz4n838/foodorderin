<?php
// Membuat koneksi ke database MySQL
// Parameter: host = "localhost", user = "root", password = "", nama database = "db_foodorderin"
$koneksi = mysqli_connect("localhost", "root", "", "db_foodorderin");

// Mengecek apakah koneksi berhasil atau tidak
if (!$koneksi) {
    // Jika koneksi gagal, tampilkan pesan error dan hentikan eksekusi program
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
