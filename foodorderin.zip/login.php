<?php
// Memulai session untuk menyimpan data user saat login
session_start();

// Menghubungkan ke database
include 'config/koneksi.php';

// Mengecek apakah form dikirim menggunakan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap input dari form login
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Mengambil data user dari database berdasarkan username
    $query = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$user'");
    $data = mysqli_fetch_assoc($query); // Mengambil hasil query sebagai array asosiatif

    // Mengecek apakah data user ditemukan, password cocok, dan role-nya adalah 'user'
    if ($data && password_verify($pass, $data['password']) && $data['role'] === 'user') {
        // Jika valid, simpan data ke session dan arahkan ke dashboard
        $_SESSION['login'] = true;
        $_SESSION['id'] = $data['id'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['role'] = $data['role'];
        header("Location: dashboard.php");
        exit;
    } else {
        // Jika gagal login, tampilkan pesan error
        $error = "Login gagal. Akun tidak ditemukan atau bukan user.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login - FoodOrderin</title>
    <!-- CDN Bootstrap untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Style tambahan untuk tampilan login -->
    <style>
        body {
            background: linear-gradient(135deg, #dbeafe, #f0f9ff);
            font-family: 'Segoe UI', sans-serif;
        }
        .login-card {
            background-color: #ffffffee;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }
        .login-title {
            font-weight: 700;
            color: #2563eb;
        }
        .form-control:focus {
            border-color: #60a5fa;
            box-shadow: 0 0 0 0.2rem rgba(96, 165, 250, 0.25);
        }
        .btn-blue {
            background-color: #2563eb;
            color: white;
            border: none;
        }
        .btn-blue:hover {
            background-color: #1d4ed8;
        }
        .link-register,
        .link-admin {
            font-size: 0.9rem;
            color: #000000;
            text-decoration: none;
        }
        .link-register:hover,
        .link-admin:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Kontainer form login, dipusatkan secara vertikal dan horizontal -->
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
        <form method="POST" class="login-card">
            <h3 class="text-center mb-4 login-title">Welcome to FoodOrderin</h3>

            <!-- Menampilkan pesan error jika login gagal -->
            <?php if (isset($error)) echo "<div class='alert alert-danger text-center'>$error</div>"; ?>

            <!-- Input username -->
            <div class="mb-3">
                <input name="username" class="form-control" placeholder="Username" required>
            </div>

            <!-- Input password -->
            <div class="mb-4">
                <input name="password" type="password" class="form-control" placeholder="Password" required>
            </div>

            <!-- Tombol submit -->
            <button type="submit" class="btn btn-blue w-100 mb-2">Login</button>

            <!-- Link tambahan: register & login admin -->
            <div class="text-center mt-2">
                <a href="register.php" class="link-register d-block mb-1">Belum punya akun? Daftar di sini</a>
                <a href="login_admin.php" class="link-admin d-block">Login sebagai Admin</a>
            </div>
        </form>
    </div>

    <!-- Menyisipkan footer jika ada -->
    <?php include 'footer.php'; ?>
</body>
</html>
