<?php
// Memulai session
session_start();

// Mengecek apakah user sudah login atau belum
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Menyimpan role dari user yang sedang login (admin/user)
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - FoodOrderin</title>
    <!-- Bootstrap CDN untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Kontainer utama -->
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="bg-white p-5 rounded shadow text-center" style="max-width: 500px; width: 100%;">
            
            <!-- Menyapa user -->
            <h3 class="mb-4">Hai, 
                <span class="text-primary"><?= $_SESSION['username'] ?></span>! 👋
            </h3>

            <!-- Menu berdasarkan role -->
            <div class="d-grid gap-3">
                <?php if ($role === 'admin') : ?>
                    <a href="menu.php" class="btn btn-warning btn-lg">Kelola Menu</a>
                    <a href="data_pesanan.php" class="btn btn-secondary btn-lg">Data Pesanan</a>
                    <a href="lihat_kontak.php" class="btn btn-outline-primary btn-lg">Lihat Masukan</a>
                <?php else: ?>
                    <a href="pesan.php" class="btn btn-info btn-lg">Pesan Makanan</a>
                    <a href="data_pesanan.php" class="btn btn-secondary btn-lg">Data Pesanan</a>
                    <a href="kontak.php" class="btn btn-outline-primary btn-lg">Beri Masukan</a>
                <?php endif; ?>

                <a href="logout.php" class="btn btn-danger btn-lg">Logout</a>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
