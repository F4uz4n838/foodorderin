<?php
// Memulai sesi untuk bisa mengakses dan menghancurkan data session
session_start();

// Menghapus semua data session yang tersimpan
session_destroy();

// Mengarahkan user kembali ke halaman login setelah logout
header("Location: login.php");
exit;
?>
