<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Mengecek apakah form dikirim menggunakan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap input dari form
    $user = $_POST['username'];
    
    // Mengenkripsi password menggunakan hashing bawaan PHP (algoritma default saat ini adalah bcrypt)
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Query untuk menyimpan data user baru ke dalam tabel 'users'
    $sql = "INSERT INTO users (username, password) VALUES ('$user', '$pass')";
    
    // Eksekusi query
    mysqli_query($koneksi, $sql);

    // Setelah berhasil, redirect ke halaman login
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - FoodOrderin</title>
    <!-- CDN Bootstrap untuk styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <!-- Kontainer untuk form pendaftaran akun, dipusatkan di tengah halaman -->
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <form method="POST" class="bg-white p-4 shadow rounded" style="min-width: 300px;">
            <h4 class="mb-3 text-center">Daftar Akun Baru</h4>

            <!-- Input username -->
            <input name="username" class="form-control mb-2" placeholder="Username" required>

            <!-- Input password -->
            <input name="password" type="password" class="form-control mb-3" placeholder="Password" required>

            <!-- Tombol untuk submit form registrasi -->
            <button type="submit" class="btn btn-success w-100">Register</button>

            <!-- Link untuk kembali ke halaman login -->
            <a href="login.php" class="d-block text-center mt-2">Sudah punya akun?</a>
        </form>
    </div>

    <!-- Menyisipkan file footer jika ada -->
    <?php include 'footer.php'; ?>
</body>
</html>
