<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session
session_start();

// Mengecek apakah user sudah login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Variabel untuk menampilkan pesan sukses setelah submit form
$show_success = false;

// Mengecek apakah form dikirim (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari session dan form
    $user_id = $_SESSION['id'];
    $menu_id = $_POST['menu_id'];
    $jumlah = $_POST['jumlah'];

    // Menyimpan data pesanan ke tabel 'pesanan' dengan status default 'Pending'
    $sql = "INSERT INTO pesanan (user_id, menu_id, jumlah, status) 
            VALUES ('$user_id', '$menu_id', '$jumlah', 'Pending')";
    
    // Eksekusi query
    mysqli_query($koneksi, $sql);

    // Tampilkan pesan sukses
    $show_success = true;
}

// Mengambil semua data menu dari database untuk pilihan dropdown
$menu = mysqli_query($koneksi, "SELECT * FROM menu");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pesan Makanan</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e0f2fe, #dbeafe);
            font-family: 'Segoe UI', sans-serif;
        }
        .card-form {
            background: white;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.08);
            padding: 30px;
            max-width: 500px;
        }
    </style>
</head>
<body>
    <!-- Container utama dengan form pemesanan makanan -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="card-form w-100">
            <h3 class="text-center mb-4 text-primary">Pesan Makanan</h3>

            <!-- Jika pesanan berhasil ditambahkan -->
            <?php if ($show_success): ?>
                <div class="alert alert-success text-center">
                    Pesanan berhasil ditambahkan! 🍽️<br><br>
                    <a href="pesan.php" class="btn btn-sm btn-primary me-2">Tambah Lagi</a>
                    <a href="dashboard.php" class="btn btn-sm btn-secondary">Selesai</a>
                </div>

            <!-- Jika belum submit atau submit gagal -->
            <?php else: ?>
                <!-- Form pemesanan -->
                <form method="POST">
                    <!-- Dropdown untuk memilih menu -->
                    <div class="mb-3">
                        <label for="menu_id" class="form-label">Pilih Menu</label>
                        <select name="menu_id" class="form-control" required>
                            <option value="">-- Pilih --</option>
                            <?php while($m = mysqli_fetch_assoc($menu)) { ?>
                                <option value="<?= $m['id'] ?>">
                                    <?= $m['nama_makanan'] ?> - Rp<?= number_format($m['harga'], 0, ',', '.') ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <!-- Input jumlah pesanan -->
                    <div class="mb-4">
                        <label for="jumlah" class="form-label">Jumlah</label>
                        <input type="number" name="jumlah" class="form-control" min="1" required>
                    </div>

                    <!-- Tombol submit dan kembali -->
                    <button type="submit" class="btn btn-blue w-100">Pesan</button>
                    <a href="dashboard.php" class="btn btn-outline-secondary w-100 mt-2">Kembali</a>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Menyisipkan footer -->
    <?php include 'footer.php'; ?>
</body>
</html>
