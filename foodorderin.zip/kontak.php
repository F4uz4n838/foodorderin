<?php
// Mulai session untuk handle login jika diperlukan
session_start();

// Hubungkan ke database
include 'config/koneksi.php';

// Jika form dikirim (via POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $pesan = $_POST['pesan'];

    // Query untuk menyimpan data ke tabel 'kontak'
    $query = "INSERT INTO kontak (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";
    mysqli_query($koneksi, $query);

    // Tampilkan notifikasi dan kembali ke halaman utama
    echo "<script>alert('Pesan berhasil dikirim!'); window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hubungi Kami</title>
    <!-- Import Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: #f0f4ff;">

<!-- Container utama -->
<div class="container mt-5">
    <h3 class="mb-4 text-center text-primary">Hubungi Kami</h3>

    <!-- Form untuk kirim pesan -->
    <form method="POST" class="bg-white p-4 rounded shadow-sm">
        <!-- Input Nama -->
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required>
        </div>

        <!-- Input Email -->
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <!-- Textarea Pesan -->
        <div class="mb-3">
            <label>Pesan</label>
            <textarea name="pesan" class="form-control" rows="4" required></textarea>
        </div>

        <!-- Tombol Kirim dan Kembali -->
        <button type="submit" class="btn btn-primary">Kirim</button>
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<!-- Tambahkan footer jika ada -->
<?php include 'footer.php'; ?>

</body>
</html>
