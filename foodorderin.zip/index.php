<?php 
// Memulai session untuk menyimpan data user ketika login
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
    <title>FoodOrderin</title>
    <meta charset="UTF-8"> <!-- Mengatur karakter encoding halaman -->
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- Agar tampilan responsif di perangkat mobile -->
    
    <!-- Link CDN Bootstrap 5 untuk styling dan grid system -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Styling tambahan -->
    <style>
        body {
            background: linear-gradient(135deg, #dbeafe, #f0f9ff); /* Gradasi warna latar */
            font-family: 'Segoe UI', sans-serif;
        }
        .hero {
            min-height: 100vh; /* Tinggi minimal 100% layar */
            display: flex;
            flex-direction: column;
            justify-content: center; /* Pusatkan konten secara vertikal */
        }
        .tagline {
            color: #2563eb; /* Warna biru tua */
            font-size: 2.5rem;
            font-weight: 700;
        }
        .desc {
            font-size: 1.1rem;
            color: #555; /* Warna abu-abu gelap */
            max-width: 500px;
        }
        .btn-blue {
            background-color: #2563eb; /* Warna tombol biru */
            color: white;
            border: none;
        }
        .btn-blue:hover {
            background-color: #1d4ed8; /* Warna saat tombol dihover */
        }
        .hero-img {
            max-width: 100%;
            height: auto;
            border-radius: 10px; /* Sudut gambar membulat */
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08); /* Bayangan gambar */
        }
    </style>
</head>
<body>

<!-- Bagian utama halaman -->
<div class="container hero">
    <div class="row align-items-center">
        <!-- Kolom kiri: teks dan tombol -->
        <div class="col-md-6 text-center text-md-start mb-4 mb-md-0">
            <h1 class="tagline mb-3">
                Selamat Datang di <span class="text-primary">FoodOrderin</span>
            </h1>
            <p class="desc mb-4">
                Platform pemesanan makanan yang mudah, cepat, dan praktis. 
                Silakan login untuk mulai memesan atau daftar jika belum punya akun.
            </p>
            <div class="d-grid gap-2 d-md-flex">
                <!-- Tombol login user -->
                <a href="login.php" class="btn btn-blue me-md-2">Login User</a>
                <!-- Tombol login admin -->
                <a href="login_admin.php" class="btn btn-outline-primary me-md-2">Login Admin</a>
                <!-- Tombol registrasi -->
                <a href="register.php" class="btn btn-success">Register</a>
            </div>
        </div>

        <!-- Kolom kanan: gambar -->
        <div class="col-md-6 text-center">
            <img src="assets/img/logo.png" class="hero-img" alt="FoodOrderin" width="400">
        </div>
    </div>
</div>

<!-- Menyisipkan file footer.php jika ada -->
<?php include 'footer.php'; ?>

</body>
</html>
