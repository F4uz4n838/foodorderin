<?php
// Mulai session dan koneksi ke database
session_start();
include 'config/koneksi.php';

// Pastikan user login dan berperan sebagai admin
if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Cek apakah parameter id dikirim lewat URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Amankan ID dengan konversi ke integer
    mysqli_query($koneksi, "DELETE FROM kontak WHERE id = $id");
}

// Setelah proses hapus, redirect balik ke halaman lihat kontak
header("Location: lihat_kontak.php");
exit;
?>
