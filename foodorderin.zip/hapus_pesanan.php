<?php
// Menghubungkan ke database
include 'config/koneksi.php';

// Memulai session
session_start();

// Cek apakah user sudah login, jika belum arahkan ke halaman login
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

// Ambil ID pesanan dari parameter URL
$id = $_GET['id'];

// Jalankan query untuk menghapus pesanan berdasarkan ID
mysqli_query($koneksi, "DELETE FROM pesanan WHERE id='$id'");

// Setelah berhasil dihapus, kembali ke halaman data pesanan
header("Location: data_pesanan.php");
exit;
?>
